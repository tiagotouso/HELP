
"""MÓDULO PARA GERAR MENSAGEM NO SISTEMAS"""

from rich import print
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from datetime import date, datetime

tamanholinha = 50

# ------------- MENSAGENS DO SISTEMA -------------

def mensagem_modelo(men, tipo, cortexto = 8, corborda = 3, blink = False):
    """Função modelo para imprimir mensagens do sistema
    Entrar
        men (mensagem string) 
        tipo (integer) {confirmação, informação, erro, ...}
        cortexto (integer); cor borda {integer}; blink {boolean}}
    Sair
        print da mensagem formadata no padrão"""
    
    # MODELOS DE CORES    
    cor = {0: 'black', 1: 'red', 2: 'green', 3: 'yellow',
           4: 'blue', 5: 'magenta', 6: 'cyan', 7: 'white',
           8: "bright_black"}

    # LIGAR E DESLIGA BLINK
    if blink:
        formatacao = 'blink ' + cor[cortexto]
    else:
        formatacao = cor[cortexto]

    # MODELOS DE ICONES
    dictipo = {0: ('✅', 'Confirmation Message'),
               1: ('⚠️', 'Information Message'), 
               2: ('❌', 'Error Message'),
               3: ('❗️', 'Exclamation Message'), 
               4: ('❓', 'Question Message'), 
               5: ('🛑', 'Stop Message')}
    
    # CONCATENAR O MODELO DE ICONE COM A MENSAGEM
    mensagem = f'\n{dictipo[tipo][0]} {men}\n'

    # CRIAR O OBJETO TEXTO COM RICH
    texto = Text(mensagem, 
                 justify = 'center', 
                 style = formatacao)
    
    # CRIAR O CONSOLE E IMPRIMI NA TELA COM RICH
    c = Console()
    c.print(Panel(texto, 
                  title = dictipo[tipo][1], 
                  style = cor[corborda]))

def mensagem_Confirmacao(men):
    """Função padrão para mensagem de confirmação"""
    mensagem_modelo(men, 0)

def mensagem_Informacao(men):
    """Função padrão para mensagem de informação"""
    mensagem_modelo(men, 1)

def mensagem_Erro(men):
    """Função padrão para mensagem de erro"""
    mensagem_modelo(men, 2)

def mensagem_Exclamacao(men):
    """Função padrão para mensagem de exclamação"""
    mensagem_modelo(men, 3)

def mensagem_Interrogacao(men):
    """Função padrão para mensagem de interrogacao"""
    mensagem_modelo(men, 4)

def mensagem_Irrupcao(men):
    """Função padrão para mensagem de interrupção"""
    mensagem_modelo(men, 5)

# ------------- MENSAGENS DO VALIDAÇÃO -------------
# ------------- FUNÇÃO AUXILIAR -------------

def verificarSair(valor):
    """Função para verificar se o usuário quer forçar a saída do sistema
    Entrar
        string == quit > return true
        string != quit > return false
    Sair
        false ou true
   """
    
    if valor.upper().strip() == 'QUIT':
        return True
    else:
        return False 
    

def verificarNumeroNatural(resp):
    """Função para verificar se o número é natural e converter o número para interger
    Entrar
        string
    Sair
        loop, valor {(true, nome) or (false, interger)}"""
    
    loop = True
    if resp.isnumeric() == True:
        valor = int(resp)
        loop = False
    else:
        valor = None
        mensagem_Erro('O valor informado não é natural!')

    return loop, valor

def verificarNumeroInteiro(resp):
    """Função para verificar se o número é inteiro e converter o número para float
    Entrar
        string
    Sair
        loop, valor {(true, nome) or (false, float)}"""

    erro = False
    if resp.count('-') <= 1 and resp.count('.') <= 1:
        if resp.count('.') == 1:
            numero, decimal = resp.split('.')
        else:
            numero, decimal = resp, '0'

        if numero.replace('-', '').isnumeric() == True  and \
            decimal.isnumeric() == True:
            valor = float(f'{numero}.{decimal}')
            loop = False
        else:
            erro = True
    else:
        erro = True

    if erro == True:
        loop = True 
        valor = None
        mensagem_Erro('O valor informado não é inteiro!')

    return loop, valor

def verificarData(valor):
    """FUNÇÃO PARA VERIFICAR SE A STRING É DATA
    Entrar
        STRING
    Sair
        LOOP, VALOR {(TRUE, NOME) OR (FALSE, DATE)}"""

    meses = {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
             7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31}
    
    valor = valor.replace('/', '').replace('-', '')

    erro = False
    if valor.isnumeric():
        if len(valor) == 6:
            ano = int(valor[0:2])
            mes = int(valor[2:4])
            dia = int(valor[4:6])

        elif len(valor) == 8:
            ano = int(valor[0:4])
            mes = int(valor[4:6])
            dia = int(valor[6:8])
        else:
            erro = True

        if erro == False:
            if ano % 4 == 0:
                meses[2] = 29

            if mes >= 1 and mes <= 12:
                if dia >= 1 and dia <= meses[mes]:
                    loop = False
                    data = date(int(ano), int(mes), int(dia))
                else:
                    erro = True
            else:
                erro = True
    else:
        erro = True

    if erro == True:
        loop = True
        data = None
        mensagem_Erro(f'O valor informado não é uma data inválida!')

    return loop, data

def verificarSimOuNao(texto):
    """FUNÇÃO PARA VERIFICAR SE SIM OU NÃO
    Entrar
        STRING S OU N
    Sair
        LOOP, VALOR {(TRUE, -1) OR (FALSE, 0) OR (FALSE, 1)}"""

    loop, valor = True, -1

    if texto.upper() == 'S':
        valor = 1
        loop = False
    elif texto.upper() == 'N':
        valor = 0
        loop = False
    else:
        mensagem_Erro('Digite "S" para sim ou "N" para não!')

    return loop, valor

def verificarLista(lista, procura):
    """Função para validar um valor na lista
    Entrar
        valores em lista e um valor procurado
    Sair
        loop, valor {(true, none) or (false, valor)}"""

    loop, valor = True, None
    
    if procura.upper() in lista:
        valor = procura.upper()
        loop = False
    else:
        mensagem_Erro(f'Digite um valor válido!')

    return loop, valor

def LoopVerificador(tipo, men, lista = None):
    """FUNÇÃO PADRÃO PARA VALIDAÇÃO DOS INPUT"""
    
    # CRIAR O OBJETO CONSOLE DO RICH
    console = Console()

    # CRIAR A MENSAGEM PADRÃO
    if tipo == 0:
        texto = Text(f' {men}\n Digite um número natural: ', style='grey58')
    elif tipo == 1:
        texto = Text(f' {men}\n Digite um número real: ', style='grey58')
    elif tipo == 2:
        texto = Text(f' {men}\n Digite uma data: ano-mês-dia: ', style='grey58')
    elif tipo == 3:
        texto = Text(f' {men}\n Digite um texto: ', style='grey58')
    elif tipo == 4:
        texto = Text(f' {men}\n Digite uma opçao: ["S", "N"]: ', style='grey58')
    elif tipo == 5:  
        for n, v in enumerate(lista):
            lista[n] = str(v).strip().upper()

        texto = Text(f' {men}\n Digite uma opções: {str(lista)}: ', style='grey58')

    # ENTRA NO LOOP ATÉ O USUÁRIO DIGITAR O VALOR CORRETO
    valor = None
    loop = True
    while loop != False:

        # CRIAR O CONSOLE INPUT DO RICH
        resp = console.input(texto)

        # VERIFICAR SE O USUÁRIO SOLICITOU INTERROMPER O PROGRAMA
        sair = verificarSair(resp)

        if sair == False:

            # VERIFICAR VALORES INTEIROS
            if tipo == 0:
                loop, valor = verificarNumeroNatural(resp)
            
            # VERIFICAR VALORES REAL
            if tipo == 1:

                loop, valor = verificarNumeroInteiro(resp)
            
            # VERIFICAR VALORES DATA
            elif tipo == 2:

                loop, valor = verificarData(resp)

            # VERIFICAR VALORES TEXTO
            elif tipo == 3:
                valor = str(resp).upper()
                loop = False
    
            # VERIFICAR VALORES SIM OU NÃO
            elif tipo == 4:

                loop, valor = verificarSimOuNao(resp)
            
            # VERIFICAR LISTA
            elif tipo == 5:
                console. print('Opções: ' + str(lista))

                loop, valor = verificarLista(lista, resp)

        else:
            loop = False
        
    return sair, valor

# ------------- MENSAGENS DO VALIDAÇÃO -------------

def men_enter_continua(men = 'Digite "Enter" para continuar. '):
    """Função para parar o sistema até a tecla enter ser precionada
    Entrar
        null ou mensagem {string}
    Sair
        null"""
    
    # criar um console com input do rich
    console = Console()
    msg = console.input(men)

def men_validar_inteiro(men):
    """Função para validar valor inteiro
    Entrar
        mensagem solicitando valor inteiro
    Sair
        tupla (sair, valor inteiro)"""
    
    sair, valor = LoopVerificador(0, men)

    return sair, valor

def men_validar_real(men):
    """Função para validar valor real
    Entrar
        mensagem solicitando valor real
    Sair
        tupla (sair, valor real)"""
    
    sair, valor = LoopVerificador(1, men)

    return sair, valor

def men_validar_data(men):
    """Função para validar data
    Entrar
        string no formato ano, mês e dia
    Sair
        tupla (sair, data {date})"""
    
    sair, valor = LoopVerificador(2, men)

    return sair, valor

def men_validar_string(men):
    """Função para entrata de texto formatados no em caixa maiúscula
    Entrar
        entra mensagem solicitando valores string
    sair
        tupla (sair, mensagem string padronizada)"""
    
    sair, valor = LoopVerificador(3, men)

    return sair, valor
    

def men_validar_SIM_NAO(men):
    """Função para validar sim ou não
    Entrar
        mensagem solicitanod resposta sim ou não
    sair
        tupla (sair, '1' para sim ou '0' para não)"""
    
    sair, valor = LoopVerificador(4, men)

    return sair, valor

def men_validar_lista(men, lista):
    """Função para verificar se o valor escolhido está na lista
    Entrar
        entra uma lista de opção
    Sair
        tupla (sair, valor escolhido)"""

    sair, valor = LoopVerificador(5, men, lista)

    return sair, valor
    

if __name__ == "__main__":
    ...
    
    # men_enter_continua()
    # men_validar_data('Informe a data')
    # men_validar_inteiro('Informe o número')
    # men_validar_real('Informe o número real')
    # men_validar_SIM_NAO('Informe S ou N')
    # men_validar_lista('Informe um valor', ['0', '1', '2'])
    # men_validar_string('Informe uma string')
 
    # mensagem_Confirmacao('Confirmação')
    # mensagem_Informacao('Informação') #*
    # mensagem_Erro('Erro')
    # mensagem_Exclamacao('Exclamação') #*
    # mensagem_Interrogacao('Interrogação')
    # mensagem_Irrupcao('Interrupção')

