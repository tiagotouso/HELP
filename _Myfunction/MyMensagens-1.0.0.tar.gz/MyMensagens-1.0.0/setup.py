from setuptools import setup

setup(
    name='MyMensagens',
    version='1.0.0',
    description='Módulo padrão para mensagem do sistema',
    author='Tiago Touso',
    author_email='tiagotouso@gmail.com',
    packages=['app'],  # Lista dos pacotes que fazem parte do seu módulo
    install_requires=['colorama==0.4.6', 'iniconfig==2.0.0', 'markdown-it-py==3.0.0', 
    'mdurl==0.1.2', 'packaging==23.1', 'pluggy==1.2.0', 'Pygments==2.15.1', 
    'rich==13.4.2'],  # Lista de dependências necessárias para o seu módulo (se houver)
)